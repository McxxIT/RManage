﻿using Microsoft.Data.SqlClient;
using Rmanage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Configuration;
namespace Rmanage.Controller
{
    public class ProductController
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["rmanage"].ConnectionString;

        ProductModel product;


        private static int GenerateUniqueProductId()
        {
            try
            {
                int product_id;
                bool isUnique;
                do
                {
                    Random random_6_digits = new Random();
                    product_id = random_6_digits.Next(100000, 999999);
                    string query = "SELECT COUNT(*) FROM tbProducts WHERE product_id = @product_id";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand checkCommand = new SqlCommand(query, connection);
                        checkCommand.Parameters.AddWithValue("@product_id", product_id);
                        connection.Open();
                        int count = (int)checkCommand.ExecuteScalar();
                        isUnique = count == 0;
                    }
                } while (!isUnique);

                return product_id;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }


        }

        public bool AddProduct(ProductModel product)
        {
            try
            {
                int product_id = GenerateUniqueProductId();
                string query = "INSERT INTO tbProducts (product_id, product_name, sku, category_id, subcategory_id) VALUES (@product_id, @product_name, @sku, @category_id, @subcategory_id)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query, connection);
                    checkCommand.Parameters.AddWithValue("@product_id", product_id);
                    checkCommand.Parameters.AddWithValue("@product_name", product.product_name);
                    checkCommand.Parameters.AddWithValue("@sku", product.sku);
                    checkCommand.Parameters.AddWithValue("@category_id", product.category_id);
                    checkCommand.Parameters.AddWithValue("@subcategory_id", product.subcategory_id);
                    connection.Open();
                    checkCommand.ExecuteNonQuery();
                    return true;
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }


        public List<ProductModel> LOAD_PRODUCTS()
        {
            try
            {
                List<ProductModel> products = new List<ProductModel>();
                string query = @"
                    SELECT p.product_id, p.product_name, p.sku, c.category_name, s.subcategory_name
                    FROM tbProducts p
                    INNER JOIN tbCategory c ON p.category_id = c.category_id
                    INNER JOIN tbSubcategory s ON p.subcategory_id = s.subcategory_id"; 
                
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = checkCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        products.Add(new ProductModel
                        {
                            product_id = Convert.ToInt32(reader["product_id"]),
                            product_name = reader["product_name"] as string ?? "",
                            sku = reader["sku"] as string ?? "",
                            category_name = reader["category_name"] as string ?? "",
                            subcategory_name = reader["subcategory_name"] as string ?? ""
                        });
                    }
                    reader.Close();
                }
                return products;

            }
            catch(Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}
