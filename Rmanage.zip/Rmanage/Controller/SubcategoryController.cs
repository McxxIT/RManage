﻿using Rmanage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Configuration;
namespace Rmanage.Controller
{
    public class SubcategoryController
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["rmanage"].ConnectionString;
        SubcategoryModel subcategoryModel;


        private static int GenerateUniqueSubcategoryId()
        {
            try
            {
                int subcategory_id;
                bool isUnique;
                do
                {
                    Random random_6_digits = new Random();
                    subcategory_id = random_6_digits.Next(100000, 999999);
                    string query = "SELECT COUNT(*) FROM tbSubcategory WHERE subcategory_id = @subcategory_id";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand checkCommand = new SqlCommand(query, connection);
                        checkCommand.Parameters.AddWithValue("@subcategory_id", subcategory_id);
                        connection.Open();
                        int count = (int)checkCommand.ExecuteScalar();
                        isUnique = count == 0;
                    }
                } while (!isUnique);

                return subcategory_id;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }


        }
        public bool AddSubcategory(SubcategoryModel subcategoryModel)
        {
            try
            {
                int subcategory_id = GenerateUniqueSubcategoryId();
                string query = "INSERT INTO tbSubcategory (subcategory_id, category_id, subcategory_name) VALUES (@subcategory_id, @category_id, @subcategory_name)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query, connection);
                    checkCommand.Parameters.AddWithValue("@subcategory_id", subcategory_id);
                    checkCommand.Parameters.AddWithValue("@category_id", subcategoryModel.category_id);
                    checkCommand.Parameters.AddWithValue("@subcategory_name", subcategoryModel.subcategory_name);
                    connection.Open();
                    checkCommand.ExecuteNonQuery();
                    return true;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public List<CategoryModel> GET_CATEGORIES()
        {
            try
            {
                List<CategoryModel> categories = new List<CategoryModel>();
                string query = "SELECT * FROM tbCategory";
                using(SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = checkCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        categories.Add(new CategoryModel
                        {
                            category_id = Convert.ToInt32(reader["category_id"]),
                            category_name = reader["category_name"] as string ?? "",
                        });
                    }
                    reader.Close();
                }
                return categories;

            }catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public List<SubcategoryModel> GET_SUBCATEGORIES()
        {
            try
            {
                List<SubcategoryModel> subcategories = new List<SubcategoryModel>();
                string query = "SELECT * FROM tbSubcategory";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query, connection);
                    connection.Open();
                    SqlDataReader reader = checkCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        subcategories.Add(new SubcategoryModel
                        {
                            subcategory_id = Convert.ToInt32(reader["subcategory_id"]),
                            subcategory_name = reader["subcategory_name"] as string ?? "",
                        });
                    }
                    reader.Close();
                }
                return subcategories;

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}
