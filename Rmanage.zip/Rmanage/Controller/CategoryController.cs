﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rmanage.Models;
using Microsoft.Data.SqlClient;
using System.Configuration;
namespace Rmanage.Controller
{
    
    public class CategoryController
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["rmanage"].ConnectionString;
        CategoryModel categoryModel;


        private static int GenerateUniqueCategoryId()
        {
            try
            {
                int category_id;
                bool isUnique;
                do
                {
                    Random random_6_digits = new Random();
                    category_id = random_6_digits.Next(100000, 999999);
                    string query = "SELECT COUNT(*) FROM tbCategory WHERE category_id = @category_id";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand checkCommand = new SqlCommand(query, connection);
                        checkCommand.Parameters.AddWithValue("@category_id", category_id);
                        connection.Open();
                        int count = (int)checkCommand.ExecuteScalar();
                        isUnique = count == 0;
                    }
                } while (!isUnique);

                return category_id;
            }catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }


        }
        public bool AddCategory(CategoryModel categoryModel)
        {
            try
            {
                int category_id = GenerateUniqueCategoryId();
                string query = "INSERT INTO tbCategory (category_id, category_name) VALUES (@category_id, @category_name)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand checkCommand = new SqlCommand(query,connection);
                    checkCommand.Parameters.AddWithValue("@category_id", category_id);
                    checkCommand.Parameters.AddWithValue("@category_name", categoryModel.category_name);
                    connection.Open();
                    checkCommand.ExecuteNonQuery();
                    return true;
                }


            }catch(Exception ex)
            {
                MessageBox.Show("An error occured: " +  ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}
