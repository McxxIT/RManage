using Rmanage.Views.Admin;

namespace Rmanage
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
        private void inventory_btn_Click(object sender, EventArgs e)
        {
            try
            {
                Inventory ShowInventory = new Inventory();
                ShowInventory.ShowDialog();




            }
            catch (Exception ex)
            {
                return;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void products_btn_Click(object sender, EventArgs e)
        {
            Product Product_Show = new Product();
            Product_Show.ShowDialog();
        }

        private void supplier_btn_Click(object sender, EventArgs e)
        {

        }
    }
}
