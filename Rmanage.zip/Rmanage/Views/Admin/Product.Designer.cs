﻿namespace Rmanage.Views.Admin
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel_container = new Panel();
            panel2 = new Panel();
            productGridView = new DataGridView();
            panel1 = new Panel();
            label2 = new Label();
            panel3 = new Panel();
            panel5 = new Panel();
            createcategory_btn = new Button();
            addproduct_btn = new Button();
            panel4 = new Panel();
            label1 = new Label();
            panel_container.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)productGridView).BeginInit();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel_container
            // 
            panel_container.Controls.Add(panel2);
            panel_container.Controls.Add(panel1);
            panel_container.Dock = DockStyle.Fill;
            panel_container.Location = new Point(0, 0);
            panel_container.Name = "panel_container";
            panel_container.Size = new Size(1615, 912);
            panel_container.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Controls.Add(productGridView);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 90);
            panel2.Name = "panel2";
            panel2.Padding = new Padding(50, 15, 50, 0);
            panel2.Size = new Size(1615, 822);
            panel2.TabIndex = 1;
            // 
            // productGridView
            // 
            productGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            productGridView.BackgroundColor = SystemColors.Control;
            productGridView.BorderStyle = BorderStyle.None;
            productGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.ButtonFace;
            dataGridViewCellStyle1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            productGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            productGridView.ColumnHeadersHeight = 50;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 12F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = Color.White;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            productGridView.DefaultCellStyle = dataGridViewCellStyle2;
            productGridView.Dock = DockStyle.Fill;
            productGridView.EnableHeadersVisualStyles = false;
            productGridView.GridColor = Color.Gainsboro;
            productGridView.Location = new Point(50, 15);
            productGridView.Name = "productGridView";
            productGridView.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 12F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            productGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            productGridView.RowHeadersVisible = false;
            productGridView.RowTemplate.Height = 50;
            productGridView.RowTemplate.Resizable = DataGridViewTriState.False;
            productGridView.Size = new Size(1515, 807);
            productGridView.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1615, 90);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Dock = DockStyle.Bottom;
            label2.Location = new Point(0, 89);
            label2.Name = "label2";
            label2.Size = new Size(1615, 1);
            label2.TabIndex = 2;
            // 
            // panel3
            // 
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(1615, 90);
            panel3.TabIndex = 1;
            // 
            // panel5
            // 
            panel5.Controls.Add(createcategory_btn);
            panel5.Controls.Add(addproduct_btn);
            panel5.Dock = DockStyle.Right;
            panel5.Location = new Point(1111, 0);
            panel5.Name = "panel5";
            panel5.Padding = new Padding(50, 25, 50, 20);
            panel5.Size = new Size(504, 90);
            panel5.TabIndex = 2;
            // 
            // createcategory_btn
            // 
            createcategory_btn.BackColor = Color.Chocolate;
            createcategory_btn.Dock = DockStyle.Left;
            createcategory_btn.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            createcategory_btn.ForeColor = Color.White;
            createcategory_btn.Location = new Point(50, 25);
            createcategory_btn.Name = "createcategory_btn";
            createcategory_btn.Size = new Size(189, 45);
            createcategory_btn.TabIndex = 1;
            createcategory_btn.Text = "Create Category";
            createcategory_btn.UseVisualStyleBackColor = false;
            createcategory_btn.Click += createcategory_btn_Click;
            // 
            // addproduct_btn
            // 
            addproduct_btn.BackColor = Color.SeaGreen;
            addproduct_btn.Dock = DockStyle.Right;
            addproduct_btn.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addproduct_btn.ForeColor = Color.White;
            addproduct_btn.Location = new Point(265, 25);
            addproduct_btn.Name = "addproduct_btn";
            addproduct_btn.Size = new Size(189, 45);
            addproduct_btn.TabIndex = 0;
            addproduct_btn.Text = "Add Product";
            addproduct_btn.UseVisualStyleBackColor = false;
            addproduct_btn.Click += addproduct_btn_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(label1);
            panel4.Dock = DockStyle.Left;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Padding = new Padding(50, 25, 0, 20);
            panel4.Size = new Size(285, 90);
            panel4.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(50, 25);
            label1.Name = "label1";
            label1.Size = new Size(114, 37);
            label1.TabIndex = 0;
            label1.Text = "Product";
            // 
            // Product
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1615, 912);
            Controls.Add(panel_container);
            Name = "Product";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin - Product";
            panel_container.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)productGridView).EndInit();
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel_container;
        private Panel panel2;
        private Panel panel1;
        private Label label1;
        private Button addproduct_btn;
        private DataGridView productGridView;
        private Label label2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Button createcategory_btn;
    }
}