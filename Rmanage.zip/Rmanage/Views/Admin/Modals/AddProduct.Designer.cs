﻿namespace Rmanage.Views.Admin.Modals
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel3 = new Panel();
            panel12 = new Panel();
            cancel_btn = new Button();
            add_btn = new Button();
            panel10 = new Panel();
            panel11 = new Panel();
            label5 = new Label();
            productname_txt = new TextBox();
            panel8 = new Panel();
            panel6 = new Panel();
            panel4 = new Panel();
            panel5 = new Panel();
            label2 = new Label();
            sku_txt = new TextBox();
            panel2 = new Panel();
            label6 = new Label();
            label1 = new Label();
            categoryid_cmb = new ComboBox();
            panel7 = new Panel();
            label3 = new Label();
            subcategoryid_cmb = new ComboBox();
            panel9 = new Panel();
            label4 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel12.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panel8.SuspendLayout();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            panel7.SuspendLayout();
            panel9.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(538, 473);
            panel1.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.Controls.Add(panel12);
            panel3.Controls.Add(panel10);
            panel3.Controls.Add(panel8);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel4);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 73);
            panel3.Name = "panel3";
            panel3.Padding = new Padding(20, 0, 20, 0);
            panel3.Size = new Size(538, 400);
            panel3.TabIndex = 1;
            // 
            // panel12
            // 
            panel12.Controls.Add(cancel_btn);
            panel12.Controls.Add(add_btn);
            panel12.Dock = DockStyle.Top;
            panel12.Location = new Point(20, 328);
            panel12.Name = "panel12";
            panel12.Size = new Size(498, 69);
            panel12.TabIndex = 6;
            // 
            // cancel_btn
            // 
            cancel_btn.Font = new Font("Segoe UI", 11F);
            cancel_btn.Location = new Point(219, 19);
            cancel_btn.Name = "cancel_btn";
            cancel_btn.Size = new Size(126, 41);
            cancel_btn.TabIndex = 5;
            cancel_btn.Text = "Cancel";
            cancel_btn.UseVisualStyleBackColor = true;
            cancel_btn.Click += cancel_btn_Click;
            // 
            // add_btn
            // 
            add_btn.BackColor = Color.SeaGreen;
            add_btn.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            add_btn.ForeColor = SystemColors.ButtonHighlight;
            add_btn.Location = new Point(369, 19);
            add_btn.Name = "add_btn";
            add_btn.Size = new Size(126, 41);
            add_btn.TabIndex = 4;
            add_btn.Text = "Add";
            add_btn.UseVisualStyleBackColor = false;
            add_btn.Click += add_btn_Click;
            // 
            // panel10
            // 
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(productname_txt);
            panel10.Dock = DockStyle.Top;
            panel10.Location = new Point(20, 246);
            panel10.Name = "panel10";
            panel10.Size = new Size(498, 82);
            panel10.TabIndex = 3;
            // 
            // panel11
            // 
            panel11.Controls.Add(label5);
            panel11.Dock = DockStyle.Fill;
            panel11.Location = new Point(0, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(498, 50);
            panel11.TabIndex = 2;
            // 
            // label5
            // 
            label5.Dock = DockStyle.Left;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(138, 50);
            label5.TabIndex = 0;
            label5.Text = "Product Name";
            label5.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // productname_txt
            // 
            productname_txt.Dock = DockStyle.Bottom;
            productname_txt.Font = new Font("Segoe UI", 14F);
            productname_txt.Location = new Point(0, 50);
            productname_txt.Name = "productname_txt";
            productname_txt.Size = new Size(498, 32);
            productname_txt.TabIndex = 1;
            // 
            // panel8
            // 
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(subcategoryid_cmb);
            panel8.Dock = DockStyle.Top;
            panel8.Location = new Point(20, 164);
            panel8.Name = "panel8";
            panel8.Size = new Size(498, 82);
            panel8.TabIndex = 2;
            // 
            // panel6
            // 
            panel6.Controls.Add(panel7);
            panel6.Controls.Add(categoryid_cmb);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(20, 82);
            panel6.Name = "panel6";
            panel6.Size = new Size(498, 82);
            panel6.TabIndex = 1;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(sku_txt);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(20, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(498, 82);
            panel4.TabIndex = 0;
            // 
            // panel5
            // 
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(498, 50);
            panel5.TabIndex = 2;
            // 
            // label2
            // 
            label2.Dock = DockStyle.Left;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(92, 50);
            label2.TabIndex = 0;
            label2.Text = "SKU";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // sku_txt
            // 
            sku_txt.Dock = DockStyle.Bottom;
            sku_txt.Font = new Font("Segoe UI", 14F);
            sku_txt.Location = new Point(0, 50);
            sku_txt.Name = "sku_txt";
            sku_txt.Size = new Size(498, 32);
            sku_txt.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(538, 73);
            panel2.TabIndex = 0;
            // 
            // label6
            // 
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Dock = DockStyle.Bottom;
            label6.Location = new Point(0, 72);
            label6.Name = "label6";
            label6.Size = new Size(538, 1);
            label6.TabIndex = 1;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(19, 14);
            label1.Name = "label1";
            label1.Size = new Size(185, 49);
            label1.TabIndex = 0;
            label1.Text = "Add Product";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // categoryid_cmb
            // 
            categoryid_cmb.Dock = DockStyle.Bottom;
            categoryid_cmb.Font = new Font("Segoe UI", 14F);
            categoryid_cmb.FormattingEnabled = true;
            categoryid_cmb.Location = new Point(0, 49);
            categoryid_cmb.Name = "categoryid_cmb";
            categoryid_cmb.Size = new Size(498, 33);
            categoryid_cmb.TabIndex = 3;
            // 
            // panel7
            // 
            panel7.Controls.Add(label3);
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(498, 49);
            panel7.TabIndex = 4;
            // 
            // label3
            // 
            label3.Dock = DockStyle.Left;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(92, 49);
            label3.TabIndex = 0;
            label3.Text = "Category";
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // subcategoryid_cmb
            // 
            subcategoryid_cmb.Dock = DockStyle.Bottom;
            subcategoryid_cmb.Font = new Font("Segoe UI", 14F);
            subcategoryid_cmb.FormattingEnabled = true;
            subcategoryid_cmb.Location = new Point(0, 49);
            subcategoryid_cmb.Name = "subcategoryid_cmb";
            subcategoryid_cmb.Size = new Size(498, 33);
            subcategoryid_cmb.TabIndex = 4;
            // 
            // panel9
            // 
            panel9.Controls.Add(label4);
            panel9.Dock = DockStyle.Fill;
            panel9.Location = new Point(0, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(498, 49);
            panel9.TabIndex = 5;
            // 
            // label4
            // 
            label4.Dock = DockStyle.Left;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(115, 49);
            label4.TabIndex = 0;
            label4.Text = "Subcategory";
            label4.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // AddProduct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(538, 473);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "AddProduct";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Product - Add Product";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel9.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Panel panel3;
        private Panel panel4;
        private TextBox sku_txt;
        private Panel panel5;
        private Label label2;
        private Panel panel10;
        private Panel panel11;
        private Label label5;
        private TextBox productname_txt;
        private Panel panel8;
        private Panel panel6;
        private Button cancel_btn;
        private Button add_btn;
        private Panel panel12;
        private Label label6;
        private ComboBox categoryid_cmb;
        private Panel panel7;
        private Label label3;
        private Panel panel9;
        private Label label4;
        private ComboBox subcategoryid_cmb;
    }
}