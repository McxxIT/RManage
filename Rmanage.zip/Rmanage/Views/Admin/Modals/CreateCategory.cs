﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.IdentityModel.Tokens;
using Rmanage.Controller;
using Rmanage.Models;

namespace Rmanage.Views.Admin.Modals
{
    public partial class CreateCategory : Form
    {
        public CreateCategory()
        {
            InitializeComponent();
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void create_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(categoryname_txt.Text))
            {
                MessageBox.Show("Please fill in the category name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var message = MessageBox.Show("Are you sure you want to create this category: " + categoryname_txt.Text + "", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (message == DialogResult.No) { return; }
            try
            {
                CategoryModel category = new CategoryModel
                {
                    category_name = categoryname_txt.Text,
                };
                CategoryController categoryController = new CategoryController();
                bool status = categoryController.AddCategory(category);
                if (status)
                {
                    categoryname_txt.Text = "";
                    MessageBox.Show("Category added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    return;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void subcategory_btn_Click(object sender, EventArgs e)
        {
            CreateSubcategory createSubcategory = new CreateSubcategory();
            createSubcategory.ShowDialog();
        }
    }
}
