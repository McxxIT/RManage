﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rmanage.Controller;
using Rmanage.Models;

namespace Rmanage.Views.Admin.Modals
{
    public partial class CreateSubcategory : Form
    {
        public CreateSubcategory()
        {
            InitializeComponent();
            LOAD_CATEGORY_INTO_CMB();
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void create_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(subcategoryname_txt.Text))
            {
                MessageBox.Show("Please fill in the subcategory name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var message = MessageBox.Show("Are you sure you want to create this subcategory: " + subcategoryname_txt.Text + "", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (message == DialogResult.No) { return; }
            try
            {
                int category_id = Convert.ToInt32(categoryid_cmb.SelectedValue);
                SubcategoryModel subcategory = new SubcategoryModel
                {
                    subcategory_name = subcategoryname_txt.Text,
                    category_id = category_id,
                };
                SubcategoryController subcategoryController = new SubcategoryController();
                bool status = subcategoryController.AddSubcategory(subcategory);
                if (status)
                {
                    subcategoryname_txt.Text = "";
                    categoryid_cmb.DataSource = null;
                    MessageBox.Show("Subcategory added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    return;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void LOAD_CATEGORY_INTO_CMB()
        {
            categoryid_cmb.DataSource = null;
            SubcategoryController subcategoryController = new SubcategoryController();
            List<CategoryModel> categories = subcategoryController.GET_CATEGORIES();

            if (categories != null && categories.Count > 0)
            {
                categoryid_cmb.DataSource = categories;
                categoryid_cmb.DisplayMember = "category_name";
                categoryid_cmb.ValueMember = "category_id";

                categoryid_cmb.SelectedIndex = -1;
            }
            else
            {
                return;
            }
        }
    }
}
