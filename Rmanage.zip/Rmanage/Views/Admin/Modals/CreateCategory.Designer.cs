﻿namespace Rmanage.Views.Admin.Modals
{
    partial class CreateCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel3 = new Panel();
            panel12 = new Panel();
            cancel_btn = new Button();
            create_btn = new Button();
            panel4 = new Panel();
            panel5 = new Panel();
            label2 = new Label();
            categoryname_txt = new TextBox();
            panel2 = new Panel();
            subcategory_btn = new Button();
            label6 = new Label();
            label1 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel12.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(538, 214);
            panel1.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.Controls.Add(panel12);
            panel3.Controls.Add(panel4);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 59);
            panel3.Name = "panel3";
            panel3.Padding = new Padding(20, 0, 20, 0);
            panel3.Size = new Size(538, 155);
            panel3.TabIndex = 1;
            // 
            // panel12
            // 
            panel12.Controls.Add(cancel_btn);
            panel12.Controls.Add(create_btn);
            panel12.Dock = DockStyle.Top;
            panel12.Location = new Point(20, 82);
            panel12.Name = "panel12";
            panel12.Size = new Size(498, 69);
            panel12.TabIndex = 6;
            // 
            // cancel_btn
            // 
            cancel_btn.Font = new Font("Segoe UI", 11F);
            cancel_btn.Location = new Point(219, 19);
            cancel_btn.Name = "cancel_btn";
            cancel_btn.Size = new Size(126, 41);
            cancel_btn.TabIndex = 5;
            cancel_btn.Text = "Cancel";
            cancel_btn.UseVisualStyleBackColor = true;
            cancel_btn.Click += cancel_btn_Click;
            // 
            // create_btn
            // 
            create_btn.BackColor = Color.SeaGreen;
            create_btn.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            create_btn.ForeColor = SystemColors.ButtonHighlight;
            create_btn.Location = new Point(369, 19);
            create_btn.Name = "create_btn";
            create_btn.Size = new Size(126, 41);
            create_btn.TabIndex = 4;
            create_btn.Text = "Create";
            create_btn.UseVisualStyleBackColor = false;
            create_btn.Click += create_btn_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(categoryname_txt);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(20, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(498, 82);
            panel4.TabIndex = 0;
            // 
            // panel5
            // 
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(498, 50);
            panel5.TabIndex = 2;
            // 
            // label2
            // 
            label2.Dock = DockStyle.Left;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(138, 50);
            label2.TabIndex = 0;
            label2.Text = "Category Name";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // categoryname_txt
            // 
            categoryname_txt.Dock = DockStyle.Bottom;
            categoryname_txt.Font = new Font("Segoe UI", 14F);
            categoryname_txt.Location = new Point(0, 50);
            categoryname_txt.Name = "categoryname_txt";
            categoryname_txt.Size = new Size(498, 32);
            categoryname_txt.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Controls.Add(subcategory_btn);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(538, 59);
            panel2.TabIndex = 0;
            // 
            // subcategory_btn
            // 
            subcategory_btn.BackColor = Color.SeaGreen;
            subcategory_btn.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            subcategory_btn.ForeColor = SystemColors.ButtonHighlight;
            subcategory_btn.Location = new Point(352, 11);
            subcategory_btn.Name = "subcategory_btn";
            subcategory_btn.Size = new Size(166, 41);
            subcategory_btn.TabIndex = 5;
            subcategory_btn.Text = "Create Subcategory";
            subcategory_btn.UseVisualStyleBackColor = false;
            subcategory_btn.Click += subcategory_btn_Click;
            // 
            // label6
            // 
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Dock = DockStyle.Bottom;
            label6.Location = new Point(0, 58);
            label6.Name = "label6";
            label6.Size = new Size(538, 1);
            label6.TabIndex = 1;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(21, 5);
            label1.Name = "label1";
            label1.Size = new Size(185, 49);
            label1.TabIndex = 0;
            label1.Text = "Create Category";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // CreateCategory
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(538, 214);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "CreateCategory";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Product - Add Category";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel3;
        private Panel panel12;
        private Button cancel_btn;
        private Button create_btn;
        private Panel panel4;
        private Panel panel5;
        private Label label2;
        private TextBox categoryname_txt;
        private Panel panel2;
        private Label label6;
        private Label label1;
        private Button subcategory_btn;
    }
}