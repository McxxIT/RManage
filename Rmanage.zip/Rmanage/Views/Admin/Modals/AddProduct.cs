﻿using Microsoft.IdentityModel.Tokens;
using Rmanage.Controller;
using Rmanage.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rmanage.Views.Admin.Modals
{
    public partial class AddProduct : Form
    {
        public AddProduct()
        {
            InitializeComponent();
            GETDATA();
        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void GETDATA()
        {
            CategoryController CategoryController = new CategoryController();
            SubcategoryController subcategoryController = new SubcategoryController();

            List<CategoryModel> categories = subcategoryController.GET_CATEGORIES();
            List<SubcategoryModel> subcategories = subcategoryController.GET_SUBCATEGORIES();

            categoryid_cmb.DataSource = null;
            subcategoryid_cmb.DataSource = null;
            if (categories != null && categories.Count > 0)
            {
                categoryid_cmb.DataSource = categories;
                categoryid_cmb.DisplayMember = "category_name";
                categoryid_cmb.ValueMember = "category_id";

                categoryid_cmb.SelectedIndex = -1;
            }
            else
            {
                return;
            }

            if(subcategories != null && subcategories.Count > 0)
            {
                subcategoryid_cmb.DataSource=subcategories;
                subcategoryid_cmb.DisplayMember = "subcategory_name";
                subcategoryid_cmb.ValueMember = "subcategory_id";

                subcategoryid_cmb.SelectedIndex = -1;
            }
            else
            {
                return;
            }

        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(productname_txt.Text))
            {
                MessageBox.Show("Please fill in the product name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(categoryid_cmb.Text))
            {
                MessageBox.Show("Please select a category.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrEmpty(sku_txt.Text))
            {
                MessageBox.Show("Please select a SKU.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrEmpty(subcategoryid_cmb.Text))
            {
                MessageBox.Show("Please select a subcategory.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(productname_txt.Text) && string.IsNullOrEmpty(categoryid_cmb.Text) && (string.IsNullOrEmpty(sku_txt.Text) && string.IsNullOrEmpty(subcategoryid_cmb.Text)))
            {
                MessageBox.Show("Please select the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var message = MessageBox.Show("Are you sure you want to add this product: " + productname_txt.Text + "", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (message == DialogResult.No) { return; }
            try
            {
                int category_id = Convert.ToInt32(categoryid_cmb.SelectedValue);
                int subcategory_id = Convert.ToInt32(subcategoryid_cmb.SelectedValue);
                ProductModel product = new ProductModel
                {
                    product_name = productname_txt.Text,
                    sku = sku_txt.Text,
                    category_id = category_id,
                    subcategory_id= subcategory_id,
                };
                ProductController productController = new ProductController();
                bool status = productController.AddProduct(product);
                if (status)
                {
                    productname_txt.Text = "";
                    sku_txt.Text = "";
                    categoryid_cmb.DataSource = null;
                    subcategoryid_cmb.DataSource = null;
                    MessageBox.Show("Product added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    return;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
    }
}
