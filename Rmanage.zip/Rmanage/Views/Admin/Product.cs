﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rmanage.Controller;
using Rmanage.Views.Admin.Modals;
using Rmanage.Models;

namespace Rmanage.Views.Admin
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void addproduct_btn_Click(object sender, EventArgs e)
        {
            AddProduct AddProduct_Show = new AddProduct();
            AddProduct_Show.ShowDialog();
            LoadProducts();
        }

        private void createcategory_btn_Click(object sender, EventArgs e)
        {
            CreateCategory CreateCategory_Show = new CreateCategory();  
            CreateCategory_Show.ShowDialog();
        }

        private void LoadProducts()
        {
            try
            {
                ProductController productController = new ProductController();
                List<ProductModel> products = productController.LOAD_PRODUCTS();

                if (products != null && products.Count > 0)
                {
                    productGridView.DataSource = new BindingList<ProductModel>(products);
                }
                else
                {
                    productGridView.DataSource = new BindingList<ProductModel>();
                }

                // Set column headers
                var columns = productGridView.Columns;

                columns["product_id"].HeaderText = "Product ID";
                columns["product_name"].HeaderText = "Product Name";
                columns["sku"].HeaderText = "SKU";
                columns["category_name"].HeaderText = "Category";
                columns["subcategory_name"].HeaderText = "Subcategory";

                // Add "Actions" column
                if (!columns.Contains("Actions"))
                {
                    DataGridViewTextBoxColumn actionsColumn = new DataGridViewTextBoxColumn
                    {
                        Name = "Actions",
                        HeaderText = "Actions",
                        ReadOnly = true
                    };
                    productGridView.Columns.Add(actionsColumn);
                }

                productGridView.AllowUserToAddRows = false;
                productGridView.ClearSelection();
                productGridView.CurrentCell = null;

                // Attach DataBindingComplete to add buttons
                productGridView.DataBindingComplete += ProductGridView_DataBindingComplete;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ProductGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in productGridView.Rows)
            {
                // Clear previous controls (if any) to avoid duplication
                row.Cells["Actions"].Value = null;

                // Create Update button
                Button updateButton = new Button
                {
                    Text = "Update",
                    BackColor = Color.Yellow,
                    ForeColor = Color.Black,
                    Width = 85,
                    Height = 40,
                    Anchor = AnchorStyles.Left
                };
                updateButton.Click += (s, ev) => HandleUpdateButtonClick((int)row.Cells["product_id"].Value);

                // Create Archive button
                Button archiveButton = new Button
                {
                    Text = "Archive",
                    BackColor = Color.Red,
                    ForeColor = Color.White,
                    Width = 85,
                    Height = 40,
                    Anchor = AnchorStyles.Right
                };
                archiveButton.Click += (s, ev) => HandleArchiveButtonClick((int)row.Cells["product_id"].Value);

                // Add buttons to panel
                FlowLayoutPanel panel = new FlowLayoutPanel
                {
                    FlowDirection = FlowDirection.LeftToRight,
                    AutoSize = true,
                    BackColor = Color.White,
                    Margin = new Padding(0),
                    Padding = new Padding(0)
                };
                panel.Controls.Add(updateButton);
                panel.Controls.Add(archiveButton);

                // Add panel to cell
                Rectangle cellRect = productGridView.GetCellDisplayRectangle(row.Cells["Actions"].ColumnIndex, row.Index, true);
                panel.Location = new Point(cellRect.X + 2, cellRect.Y + 2);
                panel.Width = cellRect.Width - 4;
                panel.Height = cellRect.Height - 4;

                productGridView.Controls.Add(panel);
            }
        }

        private void HandleUpdateButtonClick(int productId)
        {
            MessageBox.Show($"Update button clicked for Product ID: {productId}");
        }

        private void HandleArchiveButtonClick(int productId)
        {
            MessageBox.Show($"Archive button clicked for Product ID: {productId}");
        }

    }
}
