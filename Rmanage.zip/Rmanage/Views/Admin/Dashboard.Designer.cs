﻿namespace Rmanage
{
    partial class Dashboard
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dashboard_Container = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel4 = new Panel();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            supplier_btn = new Button();
            products_btn = new Button();
            inventory_btn = new Button();
            panel3 = new Panel();
            dashboard_Container.SuspendLayout();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // dashboard_Container
            // 
            dashboard_Container.Controls.Add(panel2);
            dashboard_Container.Controls.Add(panel1);
            dashboard_Container.Dock = DockStyle.Fill;
            dashboard_Container.Location = new Point(0, 0);
            dashboard_Container.Name = "dashboard_Container";
            dashboard_Container.Size = new Size(1535, 845);
            dashboard_Container.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonFace;
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(280, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1255, 845);
            panel2.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Padding = new Padding(10);
            panel1.Size = new Size(280, 845);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // panel4
            // 
            panel4.Controls.Add(button5);
            panel4.Controls.Add(button4);
            panel4.Controls.Add(button3);
            panel4.Controls.Add(supplier_btn);
            panel4.Controls.Add(products_btn);
            panel4.Controls.Add(inventory_btn);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(10, 101);
            panel4.Name = "panel4";
            panel4.Padding = new Padding(0, 10, 0, 10);
            panel4.Size = new Size(258, 478);
            panel4.TabIndex = 3;
            // 
            // button5
            // 
            button5.Dock = DockStyle.Top;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 12F);
            button5.Image = Properties.Resources.inventory_icon;
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(0, 295);
            button5.Name = "button5";
            button5.Size = new Size(258, 57);
            button5.TabIndex = 5;
            button5.Text = "   Personnels";
            button5.TextImageRelation = TextImageRelation.ImageBeforeText;
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Dock = DockStyle.Top;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 12F);
            button4.Image = Properties.Resources.inventory_icon;
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(0, 238);
            button4.Name = "button4";
            button4.Size = new Size(258, 57);
            button4.TabIndex = 4;
            button4.Text = "   Archive";
            button4.TextImageRelation = TextImageRelation.ImageBeforeText;
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 12F);
            button3.Image = Properties.Resources.inventory_icon;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(0, 181);
            button3.Name = "button3";
            button3.Size = new Size(258, 57);
            button3.TabIndex = 3;
            button3.Text = "   Transaction History";
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = true;
            // 
            // supplier_btn
            // 
            supplier_btn.Dock = DockStyle.Top;
            supplier_btn.FlatAppearance.BorderSize = 0;
            supplier_btn.FlatStyle = FlatStyle.Flat;
            supplier_btn.Font = new Font("Segoe UI", 12F);
            supplier_btn.Image = Properties.Resources.plus;
            supplier_btn.ImageAlign = ContentAlignment.MiddleLeft;
            supplier_btn.Location = new Point(0, 124);
            supplier_btn.Name = "supplier_btn";
            supplier_btn.Size = new Size(258, 57);
            supplier_btn.TabIndex = 2;
            supplier_btn.Text = "   Supplier";
            supplier_btn.TextImageRelation = TextImageRelation.ImageBeforeText;
            supplier_btn.UseVisualStyleBackColor = true;
            supplier_btn.Click += supplier_btn_Click;
            // 
            // products_btn
            // 
            products_btn.Dock = DockStyle.Top;
            products_btn.FlatAppearance.BorderSize = 0;
            products_btn.FlatStyle = FlatStyle.Flat;
            products_btn.Font = new Font("Segoe UI", 12F);
            products_btn.Image = Properties.Resources.plus;
            products_btn.ImageAlign = ContentAlignment.MiddleLeft;
            products_btn.Location = new Point(0, 67);
            products_btn.Name = "products_btn";
            products_btn.Size = new Size(258, 57);
            products_btn.TabIndex = 1;
            products_btn.Text = "   Products";
            products_btn.TextImageRelation = TextImageRelation.ImageBeforeText;
            products_btn.UseVisualStyleBackColor = true;
            products_btn.Click += products_btn_Click;
            // 
            // inventory_btn
            // 
            inventory_btn.Dock = DockStyle.Top;
            inventory_btn.FlatAppearance.BorderSize = 0;
            inventory_btn.FlatStyle = FlatStyle.Flat;
            inventory_btn.Font = new Font("Segoe UI", 12F);
            inventory_btn.Image = Properties.Resources.inventory;
            inventory_btn.ImageAlign = ContentAlignment.MiddleLeft;
            inventory_btn.Location = new Point(0, 10);
            inventory_btn.Name = "inventory_btn";
            inventory_btn.Size = new Size(258, 57);
            inventory_btn.TabIndex = 0;
            inventory_btn.Text = "   Inventory";
            inventory_btn.TextImageRelation = TextImageRelation.ImageBeforeText;
            inventory_btn.UseVisualStyleBackColor = true;
            inventory_btn.Click += inventory_btn_Click;
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(10, 10);
            panel3.Name = "panel3";
            panel3.Size = new Size(258, 91);
            panel3.TabIndex = 2;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1535, 845);
            Controls.Add(dashboard_Container);
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin";
            WindowState = FormWindowState.Maximized;
            dashboard_Container.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel dashboard_Container;
        private Panel panel2;
        private Panel panel1;
        private Button inventory_btn;
        private Panel panel3;
        private Panel panel4;
        private Button button2;
        private Button products_btn;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button supplier_btn;
    }
}
