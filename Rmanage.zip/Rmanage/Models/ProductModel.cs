﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rmanage.Models
{
    public class ProductModel
    {

        public int product_id { get; set; }
        public string product_name { get; set; }

        public string sku { get; set; }
        public int category_id { get; set; }
        public int subcategory_id { get; set; }

        public string category_name { get; set; }
        public string subcategory_name { get; set; }

       
    }
}
