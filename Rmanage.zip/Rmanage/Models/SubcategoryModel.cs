﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rmanage.Models
{
    public class SubcategoryModel
    {
        public int subcategory_id { get; set; }
        public int category_id { get; set; }
        public string subcategory_name { get; set; }

    }
}
