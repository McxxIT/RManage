﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rmanage.Models
{
    public class CategoryModel
    {

        public int category_id { get; set; }
        public string category_name { get; set; }
    }
}
